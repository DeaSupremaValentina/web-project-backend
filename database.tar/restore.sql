--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Italian_Italy.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: commenti_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.commenti_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.commenti_id OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: commenti; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.commenti (
    username character varying,
    contenuto character varying,
    ricetta integer,
    codice integer DEFAULT nextval('public.commenti_id'::regclass) NOT NULL
);


ALTER TABLE public.commenti OWNER TO postgres;

--
-- Name: contatti; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contatti (
    formato text NOT NULL,
    valore text
);


ALTER TABLE public.contatti OWNER TO postgres;

--
-- Name: daapprovare; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.daapprovare (
    nomericetta character varying,
    categoria character varying,
    linkyoutube character varying,
    linkspotify character varying,
    listaingredienti text,
    descrizione text,
    npersone character varying,
    tempi character varying,
    tag1 character varying,
    tag2 character varying,
    immagine character varying,
    publisher character varying,
    difficolta character varying,
    costo character varying,
    procedimento text
);


ALTER TABLE public.daapprovare OWNER TO postgres;

--
-- Name: ricette_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ricette_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ricette_id OWNER TO postgres;

--
-- Name: ricette; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ricette (
    codice integer DEFAULT 'public.ricette_id'::regclass NOT NULL,
    nomericetta character varying,
    categoria character varying,
    publisher character varying,
    link_youtube character varying,
    link_spotify character varying,
    listaingredienti text,
    descrizione text,
    npersone character varying,
    tempi character varying,
    tag1 character varying,
    tag2 character varying,
    immagine text,
    procedimento text,
    difficolta character varying,
    costo character varying
);


ALTER TABLE public.ricette OWNER TO postgres;

--
-- Name: ricettesalvate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ricettesalvate (
    utente character varying NOT NULL,
    ricetta integer NOT NULL
);


ALTER TABLE public.ricettesalvate OWNER TO postgres;

--
-- Name: utente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.utente (
    username character varying NOT NULL,
    nome character varying,
    mail character varying,
    tipo character varying
);


ALTER TABLE public.utente OWNER TO postgres;

--
-- Name: valutazioni_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.valutazioni_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.valutazioni_id OWNER TO postgres;

--
-- Data for Name: commenti; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.commenti (username, contenuto, ricetta, codice) FROM stdin;
\.
COPY public.commenti (username, contenuto, ricetta, codice) FROM '$$PATH$$/4818.dat';

--
-- Data for Name: contatti; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contatti (formato, valore) FROM stdin;
\.
COPY public.contatti (formato, valore) FROM '$$PATH$$/4823.dat';

--
-- Data for Name: daapprovare; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.daapprovare (nomericetta, categoria, linkyoutube, linkspotify, listaingredienti, descrizione, npersone, tempi, tag1, tag2, immagine, publisher, difficolta, costo, procedimento) FROM stdin;
\.
COPY public.daapprovare (nomericetta, categoria, linkyoutube, linkspotify, listaingredienti, descrizione, npersone, tempi, tag1, tag2, immagine, publisher, difficolta, costo, procedimento) FROM '$$PATH$$/4824.dat';

--
-- Data for Name: ricette; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ricette (codice, nomericetta, categoria, publisher, link_youtube, link_spotify, listaingredienti, descrizione, npersone, tempi, tag1, tag2, immagine, procedimento, difficolta, costo) FROM stdin;
\.
COPY public.ricette (codice, nomericetta, categoria, publisher, link_youtube, link_spotify, listaingredienti, descrizione, npersone, tempi, tag1, tag2, immagine, procedimento, difficolta, costo) FROM '$$PATH$$/4817.dat';

--
-- Data for Name: ricettesalvate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ricettesalvate (utente, ricetta) FROM stdin;
\.
COPY public.ricettesalvate (utente, ricetta) FROM '$$PATH$$/4822.dat';

--
-- Data for Name: utente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.utente (username, nome, mail, tipo) FROM stdin;
\.
COPY public.utente (username, nome, mail, tipo) FROM '$$PATH$$/4816.dat';

--
-- Name: commenti_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.commenti_id', 22, true);


--
-- Name: ricette_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ricette_id', 1, false);


--
-- Name: valutazioni_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.valutazioni_id', 1, false);


--
-- Name: commenti commenti_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commenti
    ADD CONSTRAINT commenti_pk PRIMARY KEY (codice);


--
-- Name: contatti contatti_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contatti
    ADD CONSTRAINT contatti_pk PRIMARY KEY (formato);


--
-- Name: ricette ricette_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ricette
    ADD CONSTRAINT ricette_pk PRIMARY KEY (codice);


--
-- Name: ricettesalvate ricettesalvate_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ricettesalvate
    ADD CONSTRAINT ricettesalvate_pk PRIMARY KEY (utente, ricetta);


--
-- Name: utente user_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utente
    ADD CONSTRAINT user_pk PRIMARY KEY (username);


--
-- Name: daapprovare daapprovare_utente_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daapprovare
    ADD CONSTRAINT daapprovare_utente_fk FOREIGN KEY (publisher) REFERENCES public.utente(username);


--
-- Name: ricette ricette_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ricette
    ADD CONSTRAINT ricette_user_fk FOREIGN KEY (publisher) REFERENCES public.utente(username);


--
-- Name: ricettesalvate ricettesalvate_ricette_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ricettesalvate
    ADD CONSTRAINT ricettesalvate_ricette_fk FOREIGN KEY (ricetta) REFERENCES public.ricette(codice);


--
-- Name: ricettesalvate ricettesalvate_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ricettesalvate
    ADD CONSTRAINT ricettesalvate_user_fk FOREIGN KEY (utente) REFERENCES public.utente(username);


--
-- PostgreSQL database dump complete
--

