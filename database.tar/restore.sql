--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Italian_Italy.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: commenti; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.commenti (
    username character varying,
    contenuto character varying,
    ricetta integer,
    codice integer NOT NULL
);


ALTER TABLE public.commenti OWNER TO postgres;

--
-- Name: commenti_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.commenti_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.commenti_id OWNER TO postgres;

--
-- Name: daapprovare; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.daapprovare (
    nomericetta character varying,
    categoria character varying,
    publisher character varying,
    linkyoutube character varying,
    linkspotify character varying,
    listaingredienti character varying,
    descrizione character varying,
    npersone character varying,
    tempi character varying,
    tag1 character varying,
    tag2 character varying,
    immagine character varying,
    "user" character varying,
    difficolta character varying,
    costo character varying
);


ALTER TABLE public.daapprovare OWNER TO postgres;

--
-- Name: ricette; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ricette (
    codice integer NOT NULL,
    nomericetta character varying,
    categoria character varying,
    publisher character varying,
    "link youtube" character varying,
    link_spotify character varying,
    listaingredienti character varying,
    descrizione character varying,
    npersone character varying,
    tempi character varying,
    tag1 character varying,
    tag2 character varying,
    immagine character varying,
    procedimento character varying,
    difficolta character varying,
    costo character varying
);


ALTER TABLE public.ricette OWNER TO postgres;

--
-- Name: ricette_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ricette_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ricette_id OWNER TO postgres;

--
-- Name: ricettesalvate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ricettesalvate (
    utente character varying,
    ricetta integer
);


ALTER TABLE public.ricettesalvate OWNER TO postgres;

--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    username character varying NOT NULL,
    nome character varying,
    email character varying,
    tipo character varying,
    "pathImage" character varying
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: valutazioni; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.valutazioni (
    ricetta integer,
    voto integer,
    codice integer NOT NULL
);


ALTER TABLE public.valutazioni OWNER TO postgres;

--
-- Name: valutazioni_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.valutazioni_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.valutazioni_id OWNER TO postgres;

--
-- Data for Name: commenti; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.commenti (username, contenuto, ricetta, codice) FROM stdin;
\.
COPY public.commenti (username, contenuto, ricetta, codice) FROM '$$PATH$$/4816.dat';

--
-- Data for Name: daapprovare; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.daapprovare (nomericetta, categoria, publisher, linkyoutube, linkspotify, listaingredienti, descrizione, npersone, tempi, tag1, tag2, immagine, "user", difficolta, costo) FROM stdin;
\.
COPY public.daapprovare (nomericetta, categoria, publisher, linkyoutube, linkspotify, listaingredienti, descrizione, npersone, tempi, tag1, tag2, immagine, "user", difficolta, costo) FROM '$$PATH$$/4817.dat';

--
-- Data for Name: ricette; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ricette (codice, nomericetta, categoria, publisher, "link youtube", link_spotify, listaingredienti, descrizione, npersone, tempi, tag1, tag2, immagine, procedimento, difficolta, costo) FROM stdin;
\.
COPY public.ricette (codice, nomericetta, categoria, publisher, "link youtube", link_spotify, listaingredienti, descrizione, npersone, tempi, tag1, tag2, immagine, procedimento, difficolta, costo) FROM '$$PATH$$/4815.dat';

--
-- Data for Name: ricettesalvate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ricettesalvate (utente, ricetta) FROM stdin;
\.
COPY public.ricettesalvate (utente, ricetta) FROM '$$PATH$$/4822.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (username, nome, email, tipo, "pathImage") FROM stdin;
\.
COPY public."user" (username, nome, email, tipo, "pathImage") FROM '$$PATH$$/4814.dat';

--
-- Data for Name: valutazioni; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.valutazioni (ricetta, voto, codice) FROM stdin;
\.
COPY public.valutazioni (ricetta, voto, codice) FROM '$$PATH$$/4818.dat';

--
-- Name: commenti_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.commenti_id', 1, false);


--
-- Name: ricette_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ricette_id', 1, false);


--
-- Name: valutazioni_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.valutazioni_id', 1, false);


--
-- Name: commenti commenti_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commenti
    ADD CONSTRAINT commenti_pk PRIMARY KEY (codice);


--
-- Name: ricette ricette_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ricette
    ADD CONSTRAINT ricette_pk PRIMARY KEY (codice);


--
-- Name: user user_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pk PRIMARY KEY (username);


--
-- Name: valutazioni valutazioni_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.valutazioni
    ADD CONSTRAINT valutazioni_pk PRIMARY KEY (codice);


--
-- Name: commenti commenti_ricette_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commenti
    ADD CONSTRAINT commenti_ricette_fk FOREIGN KEY (ricetta) REFERENCES public.ricette(codice);


--
-- Name: commenti commenti_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commenti
    ADD CONSTRAINT commenti_user_fk FOREIGN KEY (username) REFERENCES public."user"(username);


--
-- Name: daapprovare daapprovare_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daapprovare
    ADD CONSTRAINT daapprovare_user_fk FOREIGN KEY ("user") REFERENCES public."user"(username);


--
-- Name: ricette ricette_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ricette
    ADD CONSTRAINT ricette_user_fk FOREIGN KEY (publisher) REFERENCES public."user"(username);


--
-- Name: ricettesalvate ricettesalvate_ricette_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ricettesalvate
    ADD CONSTRAINT ricettesalvate_ricette_fk FOREIGN KEY (ricetta) REFERENCES public.ricette(codice);


--
-- Name: ricettesalvate ricettesalvate_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ricettesalvate
    ADD CONSTRAINT ricettesalvate_user_fk FOREIGN KEY (utente) REFERENCES public."user"(username);


--
-- PostgreSQL database dump complete
--

